using UnityEngine;

public class F2FMakeFoodInventory : MonoBehaviour
{


    public bool HaveSalt = false;

    public bool HavePepper = false;

    public int NumberofEggs = 0; // 0 no eggs, other that 0 = eggs


}
